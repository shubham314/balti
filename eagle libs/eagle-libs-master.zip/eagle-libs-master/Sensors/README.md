Sensor Lib
=========

This lib contain all sensors like infrared sensor, switchs, etc.

Content :
* SLIDE_SWITCH_RS : A slide switch (ref RS : 734-7315)