Connector Lib
=========

This lib contain all connectors like molex connectors, etc.

Content :
* MOLEX_MINIFIT_JR : Molex Mini-Fit Jr. 2 pins