IC Lib
=========

This lib contain all IC and boards like a chip or arduinos, level shifters, etc. that will be embeeded in another board via female/male pins.

Content :
* Arduino Nano V3
* Adafruit Level shifter 4-channel I2C-safe Bi-directional BSS138
* A4988_STEP : Pololu A4988 Stepper Motor Driver Carrier
* L6235 : Driver for Three-phase brushless DC motor