# Unipolar-Stepper-Library

Based on default Arduino Stepper Library and the sketch you find here www.instructables.com/id/BYJ48-Stepper-Motor/

To be used for 4 wires BYJ48 Stepper Motors
